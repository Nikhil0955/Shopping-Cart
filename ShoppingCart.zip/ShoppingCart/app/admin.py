from django.contrib import admin
from django.contrib.admin.options import ModelAdmin
from django.utils.html import format_html
from django.urls import reverse

#model Regestration
from .models import(
    customer,
    Product,
    cart,
    orderPlaced,
    ProductReiew
)

@admin.register(customer)
class CustomerModelAdmin(admin.ModelAdmin):
    list_display=['id','user','name','locality','city','zipcode']

@admin.register(Product)
class ProductModelAdmin(admin.ModelAdmin):
    list_display=['id','title','selling_price','discounted_price','description','category','product_image']

@admin.register(cart)
class ProductModelAdmin(admin.ModelAdmin):
    list_display=['id','user','product','quantity']

@admin.register(orderPlaced)
class ProductModelAdmin(admin.ModelAdmin):
    list_display=['id','user','customer','customer_info','product','quantity','order_date','status']
    def customer_info(self,obj):
        link=reverse("admin:app_customer_change",args=[obj.customer.pk])
        return format_html('<a href="{}">{}</a>',link,obj.customer.name)

@admin.register(ProductReiew)
class ProductModelAdmin(admin.ModelAdmin):
    list_display=['id','product','user']